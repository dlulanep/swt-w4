// Sample product data
const products = [
  { brand: "Apple", price: 1499, storage: "256GB" },
  { brand: "Samsung", price: 999, storage: "128GB" },
  { brand: "Apple", price: 1299, storage: "128GB" },
  { brand: "Google", price: 899, storage: "128GB" }
];

// Filter function for brand
function filterByBrand(products, brand) {
  return products.filter(p => p.brand === brand);
}

// Test: Filter for Apple products
const appleProducts = filterByBrand(products, "Apple");

console.log("Filtered Apple products:", appleProducts);

// Expected output: Only products with brand "Apple"
if (
  appleProducts.length === 2 &&
  appleProducts.every(p => p.brand === "Apple")
) {
  console.log("✅ Test passed: Only Apple products are returned.");
} else {
  console.log("❌ Test failed: Non-Apple products found in result.");
}