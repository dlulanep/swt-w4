// Test: Filter products when price range is 1000-1500
const testProducts = [
  { id: 1, brand: 'apple', name: 'iPhone 13', price: 799, storage: 128 },
  { id: 2, brand: 'samsung', name: 'Galaxy S22', price: 999, storage: 256 },
  { id: 3, brand: 'google', name: 'Pixel 6', price: 599, storage: 128 },
  { id: 4, brand: 'apple', name: 'iPhone SE', price: 429, storage: 64 },
  { id: 5, brand: 'samsung', name: 'Galaxy Z Flip', price: 1299, storage: 512 },
  { id: 6, brand: 'apple', name: 'iPhone 14 Pro', price: 1499, storage: 1024 }
];

function filterByPriceRange(products, priceRange) {
  const [min, max] = priceRange.split('-').map(Number);
  return products.filter(p => p.price >= min && p.price <= max);
}

// Run the test
const filtered = filterByPriceRange(testProducts, "1000-1500");
console.log(filtered);

// Expected output: Galaxy Z Flip ($1299) and iPhone 14 Pro ($1499)
if (
  filtered.length === 2 &&
  filtered.some(p => p.name === "Galaxy Z Flip") &&
  filtered.some(p => p.name === "iPhone 14 Pro")
) {
  console.log("✅ Test passed: Correct products returned for $1000-$1500.");
} else {
  console.log("❌ Test failed: Incorrect products for $1000-$1500.");
}