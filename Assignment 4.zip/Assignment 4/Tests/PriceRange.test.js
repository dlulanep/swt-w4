// PriceRange.test.js

const filterByPriceRange = (products, priceRange) => {
    if (!priceRange) return products;
    const [minStr, maxStr] = priceRange.split('-');
    const min = minStr === '' ? -Infinity : Number(minStr);
    const max = maxStr === '' ? Infinity : Number(maxStr);
    if (isNaN(min) || isNaN(max)) return products;
    return products.filter(p => p.price >= min && p.price <= max);
};

describe('filterByPriceRange', () => {
    const products = [
        { id: 1, price: 50 },
        { id: 2, price: 150 },
        { id: 3, price: 500 },
        { id: 4, price: 1200 },
        { id: 5, price: 1600 },
    ];

    test('filters products within 100-200', () => {
        const result = filterByPriceRange(products, '100-200');
        expect(result).toEqual([{ id: 2, price: 150 }]);
    });

    test('filters products within 1000-1500', () => {
        const result = filterByPriceRange(products, '1000-1500');
        expect(result).toEqual([{ id: 4, price: 1200 }]);
    });

    test('filters products within 0-0 (should be empty)', () => {
        const result = filterByPriceRange(products, '0-0');
        expect(result).toEqual([]);
    });

    test('filters products within 0-1600 (all products)', () => {
        const result = filterByPriceRange(products, '0-1600');
        expect(result).toEqual(products);
    });

    test('filters products with invalid range (should return all)', () => {
        const result = filterByPriceRange(products, 'abc-def');
        expect(result).toEqual(products);
    });

    test('filters products with empty range (should return all)', () => {
        const result = filterByPriceRange(products, '');
        expect(result).toEqual(products);
    });

    test('filters products with only min provided (100-)', () => {
        const result = filterByPriceRange(products, '100-');
        expect(result).toEqual(products.filter(p => p.price >= 100));
    });

    test('filters products with only max provided (-200)', () => {
        const result = filterByPriceRange(products, '-200');
        expect(result).toEqual(products.filter(p => p.price <= 200));
    });
});