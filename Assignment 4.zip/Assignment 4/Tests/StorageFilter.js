// Test: Filter products with 256GB storage
const testProducts = [
  { id: 1, brand: 'apple', name: 'iPhone 13', price: 799, storage: 128 },
  { id: 2, brand: 'samsung', name: 'Galaxy S22', price: 999, storage: 256 },
  { id: 3, brand: 'google', name: 'Pixel 6', price: 599, storage: 128 },
  { id: 4, brand: 'apple', name: 'iPhone SE', price: 429, storage: 64 },
  { id: 5, brand: 'samsung', name: 'Galaxy Z Flip', price: 1299, storage: 512 },
  { id: 6, brand: 'apple', name: 'iPhone 14 Pro', price: 1499, storage: 1024 }
];

function filterByStorage(products, storage) {
  return products.filter(p => p.storage === storage);
}

// Run the test for 256GB storage
const filtered = filterByStorage(testProducts, 256);
console.log(filtered);

// Expected output: Only Galaxy S22 (256GB)
if (
  filtered.length === 1 &&
  filtered[0].name === "Galaxy S22" &&
  filtered[0].storage === 256
) {
  console.log("✅ Test passed: Only 256GB product is displayed.");
} else {
  console.log("❌ Test failed: Incorrect products for 256GB storage.");
}